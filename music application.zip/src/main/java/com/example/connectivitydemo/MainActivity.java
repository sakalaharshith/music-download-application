package com.example.connectivitydemo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.UrlQuerySanitizer;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
ConnectivityManager connectivityManager;
Button b;
TextView textView;
boolean flag=false;
ImageView imageView;
MediaPlayer mediaPlayer;
String filepath;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        connectivityManager=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
        b=(Button)findViewById(R.id.network_connectivity);
        imageView=(ImageView)findViewById(R.id.image);
        textView=(TextView)findViewById(R.id.textview);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    NetworkCapabilities networkCapabilities=connectivityManager.getNetworkCapabilities(connectivityManager.getActiveNetwork());
                    if(networkCapabilities!=null)
                    {
                        if(networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI))
                        {
                            Toast.makeText(MainActivity.this, "android 10 inside wifi ", Toast.LENGTH_SHORT).show();
                            //new download().execute("https://wallpapersite.com/images/pages/pic_w/6408.jpg");
                            new musicTask().execute(" https://drive.google.com/uc?export=download&id=1bbIROgy21zIu4toA2NTRJo_XedL8Ry9N");
                        }
                        if(networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR))
                        {
                            Toast.makeText(MainActivity.this, "android 10 inside cellular ", Toast.LENGTH_SHORT).show();
                            //new download().execute("https://wallpapersite.com/images/pages/pic_w/6408.jpg");
                            new musicTask().execute(" https://drive.google.com/uc?export=download&id=1bbIROgy21zIu4toA2NTRJo_XedL8Ry9N");
                        }
                    }
                } else {
                    NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
                    if (networkInfo != null) {
                        if (networkInfo.getType() == ConnectivityManager.TYPE_WIFI) {
                            Toast.makeText(MainActivity.this, " connecting with wifi", Toast.LENGTH_SHORT).show();
                           // new textTask().execute("https://drive.google.com/uc?export=download&id=1KLq05Or1qv6kU7ypuTREM1Hp_89SRZjb");
                                  new musicTask().execute("https://drive.google.com/uc?export=download&id=1bbIROgy21zIu4toA2NTRJo_XedL8Ry9N");
                        }
                        if (networkInfo.getType() == ConnectivityManager.TYPE_MOBILE) {
                            Toast.makeText(MainActivity.this, "connecting with mobile", Toast.LENGTH_SHORT).show();
                           // new textTask().execute("https://drive.google.com/uc?export=download&id=1KLq05Or1qv6kU7ypuTREM1Hp_89SRZjb");

                        }
                    } else {
                        Toast.makeText(MainActivity.this, "no active network", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        mediaPlayer=new MediaPlayer();
        check_write_permission();

    }

    @Override
    protected void onStop() {
        super.onStop();
        mediaPlayer.stop();
    }

    public void  check_write_permission()
    {
    if(ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)== PackageManager.PERMISSION_GRANTED)
    {
        flag=true;

    }
    else
    {
        ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},1);
    }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode==1 && grantResults.length>0)
        {
            if(grantResults[0]==PackageManager.PERMISSION_GRANTED)
            {
                check_write_permission();
            }
            else
            {
                Toast.makeText(this, "permsission is not granted", Toast.LENGTH_SHORT).show();
            }
        }
    }
  public class musicTask extends AsyncTask<String,Void,String>
  {


      @Override
      protected String doInBackground(String... strings) {
          return downloadMusic(strings[0]);

      }
 String downloadMusic(String string)
 {
     String s=null;
     try {
         URL url=new URL(string);
         HttpURLConnection httpURLConnection=(HttpURLConnection)url.openConnection();
         httpURLConnection.setRequestMethod("GET");
         httpURLConnection.setDoInput(true);
         httpURLConnection.connect();
         int code=httpURLConnection.getResponseCode();
         if (code==HttpURLConnection.HTTP_OK)
         {
             InputStream inputStream=httpURLConnection.getInputStream();
             if(inputStream!=null)
             {
                 Log.d("inside","inside input stream");
                 if(flag)
                 {
                     String state=Environment.getExternalStorageState();
                     if(state.equals(Environment.MEDIA_MOUNTED))
                     {
                         File root=Environment.getExternalStorageDirectory();
                         File f=new File(root,"music.mp3");
                         FileOutputStream fileOutputStream=new FileOutputStream(f);
                         int i=0;
                         while((i=inputStream.read())!=-1)
                         {
                             fileOutputStream.write(i);
                         }
                         Log.d("after while loop","done");
                         Log.d("path",f.getAbsolutePath());
                         s="done";
                         filepath=f.getAbsolutePath();
                         fileOutputStream.close();
                     }
                 }
             }
         }
     }catch(Exception e)
     {
        Log.d("exception",e.getMessage());
     }
    return s;
 }
      @Override
      protected void onPostExecute(String s) {
          super.onPostExecute(s);
          if(s==null)
          {
              Toast.makeText(MainActivity.this, "not downloaded", Toast.LENGTH_SHORT).show();
          }
          if(s.equals("done"))
          {
              Toast.makeText(MainActivity.this, "done", Toast.LENGTH_SHORT).show();
              try {
                  mediaPlayer.setDataSource(filepath);
                  mediaPlayer.prepare();
                  mediaPlayer.start();
              } catch (IOException e) {
                  e.printStackTrace();
              }
          }

      }
  }
    public class textTask extends AsyncTask<String,Void,String>
    {

        @Override
        protected String doInBackground(String... strings) {
            return downloadText(strings[0]);
        }
          String downloadText(String url)
          {
              String line="";
              String s="";
              try {
                  URL url1 = new URL(url);
                  HttpURLConnection httpURLConnection=(HttpURLConnection)url1.openConnection();
                  httpURLConnection.setReadTimeout(5000);
                  httpURLConnection.setConnectTimeout(5000);
                  httpURLConnection.setRequestMethod("GET");
                  httpURLConnection.setDoInput(true);
                  httpURLConnection.connect();
                  int code=httpURLConnection.getResponseCode();
                  if(code==HttpURLConnection.HTTP_OK)
                  {
                        InputStream inputStream=httpURLConnection.getInputStream();
                        if(inputStream!=null)
                        {
                            Log.d("inputstream","inside");
                            BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(inputStream));
                            Log.d("outsideloop","outside loop");
                            while ((line=bufferedReader.readLine())!=null)
                            {
                                Log.d("t","hello");
                                s=s.concat(line)+"\n";

                            }
                            Log.d("read","reading completed");
                            if(flag)
                            {
                                String state=Environment.getExternalStorageState();
                                if(state.equals(Environment.MEDIA_MOUNTED))
                                {
                                    File root=Environment.getExternalStorageDirectory();
                                    File f=new File(root,"myfile.txt");
                                    FileOutputStream fileOutputStream=new FileOutputStream(f);
                                    byte[] by =s.getBytes();
                                    fileOutputStream.write(by);
                                    Log.d("after","writing");
                                    Log.d("path","path is"+f.getAbsolutePath());
                                    fileOutputStream.close();

                                }
                            }

                        }
                  }
              }catch (Exception e)
              {
                  //Toast.makeText(MainActivity.this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();
                  Log.e("Tag",e.getMessage());
              }
                   return s;
          }
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(s!=null)
            {
            textView.setText(s);
                Toast.makeText(MainActivity.this, ""+s, Toast.LENGTH_SHORT).show();
            }

        }
    }
    public class download extends AsyncTask<String,Void, Bitmap>
    {


        @Override
        protected Bitmap doInBackground(String... strings) {
            return downloadImage(strings[0]);
        }
        Bitmap downloadImage(String s)
        {
            Bitmap bitmap=null;
            try {
                URL url=new URL(s);
                HttpURLConnection httpURLConnection=(HttpURLConnection)url.openConnection();
                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.setRequestMethod("GET");
                httpURLConnection.setDoInput(true);
                httpURLConnection.connect();
                   int code=httpURLConnection.getResponseCode();
                   if(code==HttpURLConnection.HTTP_OK)
                   {
                      InputStream inputStream=httpURLConnection.getInputStream();
                      if(inputStream!=null)
                      {
                           bitmap= BitmapFactory.decodeStream(inputStream);
                      }
                   }
                }
            catch (Exception e)
            {

            }

            return bitmap;
        }


        @Override
        protected void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
            if(bitmap!=null)
            {
                imageView.setImageBitmap(bitmap);
            }
        }
    }
}